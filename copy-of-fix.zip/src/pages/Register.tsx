import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Register() {
  const [licensePlate, setLicensePlate] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const navigate = useNavigate();

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsScanning(true);
        setScanComplete(false);
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Không thể truy cập camera. Vui lòng kiểm tra quyền truy cập.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      setIsScanning(false);
    }
  };

  const captureFace = () => {
    // Simulate face capture
    setScanComplete(true);
    stopCamera();
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanComplete) {
      alert('Vui lòng quét khuôn mặt trước khi đăng ký!');
      return;
    }
    // In a real app, this would send data to the server
    alert('Đăng ký xe thành công!');
    navigate('/dashboard');
  };

  return (
    <div className="bg-[#f8f6f6] dark:bg-[#221610] min-h-screen flex flex-col font-sans">
      {/* Main Content Container */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-[480px] bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-100 dark:border-slate-800 overflow-hidden">
          {/* Card Header/Image */}
          <div className="relative h-32 bg-[#ec5b13]/10 flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-[#ec5b13]/20 to-transparent"></div>
            <div className="relative z-10 text-center px-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Đăng ký phương tiện</h2>
              <p className="text-slate-600 dark:text-slate-400 text-sm mt-1">Nhập biển số và quét khuôn mặt</p>
            </div>
          </div>

          {/* Registration Form */}
          <form onSubmit={handleRegister} className="p-8 space-y-6">
            {/* License Plate */}
            <div className="space-y-2">
              <label className="text-slate-700 dark:text-slate-300 text-sm font-semibold flex items-center gap-2">
                <span className="material-symbols-outlined text-lg">pin</span>
                Biển số xe
              </label>
              <input 
                type="text"
                value={licensePlate}
                onChange={(e) => setLicensePlate(e.target.value.toUpperCase())}
                required
                className="w-full px-4 py-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-[#ec5b13]/20 focus:border-[#ec5b13] transition-all outline-none uppercase font-mono text-lg tracking-wider text-center" 
                placeholder="VD: 29A-123.45" 
              />
            </div>

            {/* Face Scan Section */}
            <div className="space-y-2">
              <label className="text-slate-700 dark:text-slate-300 text-sm font-semibold flex items-center gap-2">
                <span className="material-symbols-outlined text-lg">face</span>
                Quét khuôn mặt
              </label>
              
              <div className="relative w-full aspect-square bg-slate-100 dark:bg-slate-800 rounded-xl overflow-hidden border-2 border-dashed border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center">
                {!isScanning && !scanComplete && (
                  <button 
                    type="button"
                    onClick={startCamera}
                    className="flex flex-col items-center gap-3 text-slate-500 hover:text-[#ec5b13] transition-colors"
                  >
                    <span className="material-symbols-outlined text-5xl">photo_camera</span>
                    <span className="font-medium">Nhấn để mở camera</span>
                  </button>
                )}

                <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  muted 
                  className={`w-full h-full object-cover ${!isScanning ? 'hidden' : ''}`}
                />

                {isScanning && (
                  <>
                    {/* Scanning overlay */}
                    <div className="absolute inset-0 border-4 border-[#ec5b13]/50 rounded-xl pointer-events-none">
                      <div className="w-full h-1 bg-[#ec5b13] animate-[scan_2s_ease-in-out_infinite] shadow-[0_0_8px_#ec5b13]"></div>
                    </div>
                    <button 
                      type="button"
                      onClick={captureFace}
                      className="absolute bottom-4 bg-[#ec5b13] text-white px-6 py-2 rounded-full font-bold shadow-lg hover:bg-[#ec5b13]/90 transition-colors"
                    >
                      Chụp ảnh
                    </button>
                  </>
                )}

                {scanComplete && (
                  <div className="flex flex-col items-center gap-3 text-green-500">
                    <span className="material-symbols-outlined text-6xl">check_circle</span>
                    <span className="font-bold text-lg">Đã quét thành công</span>
                    <button 
                      type="button"
                      onClick={startCamera}
                      className="text-sm text-slate-500 hover:text-[#ec5b13] underline mt-2"
                    >
                      Quét lại
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Register Button */}
            <button 
              type="submit"
              disabled={!scanComplete || !licensePlate}
              className="w-full bg-[#ec5b13] hover:bg-[#ec5b13]/90 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold py-4 rounded-lg shadow-lg shadow-[#ec5b13]/20 transition-all transform active:scale-[0.98] mt-4"
            >
              Hoàn tất đăng ký
            </button>

            {/* Back to Dashboard Redirect */}
            <div className="text-center pt-4">
              <Link to="/dashboard" className="text-slate-600 dark:text-slate-400 text-sm hover:text-[#ec5b13] transition-colors flex items-center justify-center gap-1">
                <span className="material-symbols-outlined text-sm">arrow_back</span>
                Quay lại bảng điều khiển
              </Link>
            </div>
          </form>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 text-center">
        <p className="text-slate-500 dark:text-slate-500 text-xs">
          The Visionary FAIC HACKATHON PROJECT © 2026
        </p>
      </footer>
    </div>
  );
}
